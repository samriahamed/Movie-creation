import React from 'react';
import './SortOptions.css';

function SortOptions({ sortBy, sortOrder, onSortChange }) {
  const sortKeys = [
    { value: 'title', label: 'Title' },
    { value: 'genre', label: 'Genre' },
    { value: 'releaseYear', label: 'Release Year' },
    { value: 'rating', label: 'Rating' },
  ];

  const sortOrders = [
    { value: 'asc', label: 'Ascending' },
    { value: 'desc', label: 'Descending' },
  ];

  const handleKeyChange = (e) => {
    onSortChange(e.target.value, sortOrder);
  };

  const handleOrderChange = (e) => {
    onSortChange(sortBy, e.target.value);
  };

  return (
    <div className="sort-options-container">
      <label htmlFor="sort-key-select">Sort by:</label>
      <select
        id="sort-key-select"
        className="sort-select"
        value={sortBy}
        onChange={handleKeyChange}
      >
        {sortKeys.map((key) => (
          <option key={key.value} value={key.value}>
            {key.label}
          </option>
        ))}
      </select>

      <label htmlFor="sort-order-select">Order:</label>
      <select
        id="sort-order-select"
        className="sort-select"
        value={sortOrder}
        onChange={handleOrderChange}
      >
        {sortOrders.map((order) => (
          <option key={order.value} value={order.value}>
            {order.label}
          </option>
        ))}
      </select>
    </div>
  );
}

export default SortOptions; 