import React from 'react';
import './YearFilter.css';

function YearFilter({ startYear, endYear, onYearChange }) {

  const handleStartChange = (event) => {
    const value = event.target.value;
    // Allow empty string or positive numbers
    if (value === '' || /^[0-9]+$/.test(value)) {
        onYearChange(value, endYear);
    }
  };

  const handleEndChange = (event) => {
    const value = event.target.value;
    // Allow empty string or positive numbers
    if (value === '' || /^[0-9]+$/.test(value)) {
        onYearChange(startYear, value);
    }
  };

  return (
    <div className="year-filter-container">
      <label>Filter by Release Year:</label>
      <div className="year-inputs">
        <input
          type="number"
          className="year-input"
          placeholder="Start Year" // e.g., 1990
          value={startYear}
          onChange={handleStartChange}
          min="1800" // Optional: Set a reasonable minimum
          max={new Date().getFullYear()} // Optional: Set max to current year
        />
        <span>-</span>
        <input
          type="number"
          className="year-input"
          placeholder="End Year" // e.g., 2010
          value={endYear}
          onChange={handleEndChange}
          min="1800"
          max={new Date().getFullYear()}
        />
      </div>
    </div>
  );
}

export default YearFilter; 