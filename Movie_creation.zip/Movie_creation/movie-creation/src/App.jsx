import React, { useState, useMemo, useEffect } from 'react';

// Import Components
import AddMovieForm from './Components/AddMovieForm/AddMovieForm';
import SearchBar from './Components/SearchBar/SearchBar';
import GenreFilter from './Components/GenreFilter/GenreFilter';
import YearFilter from './Components/YearFilter/YearFilter';
import SortOptions from './Components/SortOption/SortOption';
import MovieList from './Components/MovieList/MovieList';
import ThemeToggle from './Components/ThemeToggle/ThemeToggle';

// Import Global CSS
import './App.css';

// Initial Movie Data (Example)
const initialMovies = [
  { id: 1, title: "Inception", genre: "Sci-Fi", releaseYear: 2010, rating: 8.8 },
  { id: 2, title: "The Dark Knight", genre: "Action", releaseYear: 2008, rating: 9.0 },
  { id: 3, title: "Parasite", genre: "Drama", releaseYear: 2019, rating: 8.6 },
  { id: 4, title: "Spirited Away", genre: "Animation", releaseYear: 2001, rating: 8.6 },
  { id: 5, title: "Interstellar", genre: "Sci-Fi", releaseYear: 2014, rating: 8.7 },
  { id: 6, title: "Pulp Fiction", genre: "Crime", releaseYear: 1994, rating: 8.9 },
];

function App() {
  // --- State Variables ---
  const [movies, setMovies] = useState(initialMovies);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('All Genres');
  const [startYear, setStartYear] = useState('');
  const [endYear, setEndYear] = useState('');
  const [sortBy, setSortBy] = useState('title'); // Default sort
  const [sortOrder, setSortOrder] = useState('asc'); // Default order

  // Theme State
  const getInitialTheme = () => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) return savedTheme;
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  };
  const [theme, setTheme] = useState(getInitialTheme);

  // --- Effects ---
  // Apply theme class to body and save preference
  useEffect(() => {
    document.body.className = `theme-${theme}`;
    localStorage.setItem('theme', theme);
  }, [theme]);

  // --- Handlers ---
  const handleAddMovie = (newMovie) => {
    setMovies(prevMovies => [...prevMovies, newMovie]);
  };

  const handleSearchChange = (newSearchTerm) => {
    setSearchTerm(newSearchTerm);
  };

  const handleGenreChange = (newGenre) => {
    setSelectedGenre(newGenre);
  };

  const handleYearChange = (newStartYear, newEndYear) => {
    setStartYear(newStartYear);
    setEndYear(newEndYear);
  };

  const handleSortChange = (newSortBy, newSortOrder) => {
    setSortBy(newSortBy);
    setSortOrder(newSortOrder);
  };

  const handleToggleTheme = () => {
    setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  // --- Memoized Calculations ---
  // Get unique genres for the filter dropdown
  const availableGenres = useMemo(() => {
    const genres = movies.map(movie => movie.genre);
    return ['All Genres', ...new Set(genres)];
  }, [movies]);

  // Process movies: filter first, then sort
  const processedMovies = useMemo(() => {
    // 1. Filtering
    const start = startYear === '' ? -Infinity : parseInt(startYear, 10);
    const end = endYear === '' ? Infinity : parseInt(endYear, 10);
    const searchLower = searchTerm.toLowerCase();

    let filtered = movies.filter(movie => {
      const titleMatch = movie.title.toLowerCase().includes(searchLower);
      const genreMatch = selectedGenre === 'All Genres' || movie.genre === selectedGenre;
      const movieYear = parseInt(movie.releaseYear, 10);
      const yearMatch = !isNaN(movieYear) && movieYear >= start && movieYear <= end;
      return titleMatch && genreMatch && yearMatch;
    });

    // 2. Sorting
    // Create a copy before sorting to avoid mutating the filtered array directly if needed elsewhere
    const sorted = [...filtered].sort((a, b) => {
      const valA = a[sortBy];
      const valB = b[sortBy];

      let comparison = 0;
      if (sortBy === 'releaseYear' || sortBy === 'rating') {
        comparison = parseFloat(valA) - parseFloat(valB);
      } else {
        // Ensure values are strings before comparing
        comparison = String(valA).toLowerCase().localeCompare(String(valB).toLowerCase());
      }

      return sortOrder === 'asc' ? comparison : comparison * -1;
    });

    return sorted;
  }, [movies, searchTerm, selectedGenre, startYear, endYear, sortBy, sortOrder]);

  // --- Render ---
  return (
    <div className="App">
      <ThemeToggle theme={theme} onToggleTheme={handleToggleTheme} />

      <h1>My Movie Collection</h1>

      <AddMovieForm onAddMovie={handleAddMovie} />

      <div className="controls-container">
        <div className="filters-container">
          <SearchBar searchTerm={searchTerm} onSearchChange={handleSearchChange} />
          <GenreFilter
            genres={availableGenres}
            selectedGenre={selectedGenre}
            onGenreChange={handleGenreChange}
          />
          <YearFilter
            startYear={startYear}
            endYear={endYear}
            onYearChange={handleYearChange}
          />
        </div>
        <SortOptions
          sortBy={sortBy}
          sortOrder={sortOrder}
          onSortChange={handleSortChange}
        />
      </div>

      <MovieList movies={processedMovies} />
    </div>
  );
}

export default App;
