import React from 'react';
import './MovieList.css';

function MovieList({ movies }) {
  if (!movies || movies.length === 0) {
    return <p className="no-movies-message">No movies match your criteria.</p>;
  }

  return (
    <div className="movie-list-container">
      <h2>Movie Collection</h2>
      <ul className="movie-list">
        {movies.map((movie) => (
          <li key={movie.id} className="movie-item">
            <h3 className="movie-title">{movie.title}</h3>
            <p className="movie-detail"><strong>Genre:</strong> {movie.genre}</p>
            <p className="movie-detail"><strong>Release Year:</strong> {movie.releaseYear}</p>
            <p className="movie-detail"><strong>Rating:</strong> {movie.rating}/10</p>
            {/* Add more details or actions (like delete/edit buttons) here if needed */}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default MovieList;
