import React, { useState } from 'react';
import './AddMovieForm.css';

function AddMovieForm({ onAddMovie }) {
  const [title, setTitle] = useState('');
  const [genre, setGenre] = useState('');
  const [releaseYear, setReleaseYear] = useState('');
  const [rating, setRating] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    // Basic validation (can be expanded)
    if (!title || !genre || !releaseYear || !rating) {
      alert('Please fill in all fields');
      return;
    }
    if (isNaN(parseInt(releaseYear)) || isNaN(parseFloat(rating))) {
        alert('Release Year must be a number and Rating must be a number.');
        return;
    }

    const newMovie = {
      id: Date.now(), // Simple way to generate a unique ID
      title,
      genre,
      releaseYear: parseInt(releaseYear),
      rating: parseFloat(rating),
    };

    onAddMovie(newMovie);

    // Clear the form
    setTitle('');
    setGenre('');
    setReleaseYear('');
    setRating('');
  };

  return (
    <form onSubmit={handleSubmit} className="add-movie-form">
      <h2>Add New Movie</h2>
      <div className="form-group">
        <label htmlFor="title">Title:</label>
        <input
          type="text"
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
      </div>
      <div className="form-group">
        <label htmlFor="genre">Genre:</label>
        <input
          type="text"
          id="genre"
          value={genre}
          onChange={(e) => setGenre(e.target.value)}
          required
        />
      </div>
      <div className="form-group">
        <label htmlFor="releaseYear">Release Year:</label>
        <input
          type="number" // Use number type for better input control
          id="releaseYear"
          value={releaseYear}
          onChange={(e) => setReleaseYear(e.target.value)}
          required
        />
      </div>
      <div className="form-group">
        <label htmlFor="rating">Rating (0-10):</label>
        <input
          type="number" // Use number type
          id="rating"
          value={rating}
          onChange={(e) => setRating(e.target.value)}
          min="0" // Add min/max for validation
          max="10"
          step="0.1" // Allow decimal ratings
          required
        />
      </div>
      <button type="submit">Add Movie</button>
    </form>
  );
}

export default AddMovieForm;
