import React from 'react';
import './GenreFilter.css';

function GenreFilter({ genres, selectedGenre, onGenreChange }) {
  // Add an "All Genres" option
  const allGenresOption = "All Genres";
  const uniqueGenres = [allGenresOption, ...new Set(genres)]; // Get unique genres and add the 'All' option

  return (
    <div className="genre-filter-container">
      <label htmlFor="genre-select">Filter by Genre:</label>
      <select
        id="genre-select"
        className="genre-select"
        value={selectedGenre}
        onChange={(e) => onGenreChange(e.target.value)}
      >
        {uniqueGenres.map((genre) => (
          <option key={genre} value={genre}>
            {genre}
          </option>
        ))}
      </select>
    </div>
  );
}

export default GenreFilter;
